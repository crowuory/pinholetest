import React from 'react';
import './App.css';
import MainScreen from "./views/MainScreen";

function App() {
  return (<MainScreen />);
}

export default App;
