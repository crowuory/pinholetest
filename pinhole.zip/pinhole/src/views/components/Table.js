import React from 'react'
import {Styles} from "../style/style";
import '../style/style.css'

export default function Table({children}) {
    return <table className='table'>{children}</table>
}
