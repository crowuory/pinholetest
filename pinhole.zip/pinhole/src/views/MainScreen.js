import React from 'react';
import Table from "./components/Table";
import Data from "../DemoDate";

export default class MainScreen extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            rawData: Data, // hold all the data from json file :: this will be replaced by rest api response
            processedData: false, // after raw data is processed, its held on this variable
            states: false, // helps in sorting the states by alhabetical order
            totals: false, // holds the total of each state category sales
        }
    }

    componentDidMount = () => this._getCategories();


    _getCategories = () => {
        let processedData = {}; // blank object to hold results
        let states = []; // blank array to old states for sorting
        this.state.rawData.map(row => {
            if (typeof (processedData[row.category]) === 'undefined') { // check if this processedData[row.category] exist
                processedData[row.category] = new Object(); // initialize the object
            }
            if (typeof (processedData[row.category][row.subCategory]) === 'undefined') { // same as process above for subcategory
                processedData[row.category][row.subCategory] = new Object();
            }
            if (typeof (processedData[row.category][row.subCategory][row.state]) === 'undefined') {// same as process above for state
                processedData[row.category][row.subCategory][row.state] = 0;
            }
            let index = processedData[row.category][row.subCategory][row.state].length
            processedData[row.category][row.subCategory][row.state] += row.sales; // get summation of sales in state by incrementing
            if (!states.includes(row.state)) states[states.length] = row.state; // create an array of all the states
        });
        states.sort(); // sorts the array of states in line 37

        this.setState({processedData, states}, this._handleSortingCategories); // update process data and call _handleSortingCategories for sorting
    }

    _handleSortingSubCategories = (subCategory) => {
        // Collect all keys of the object subcategory in arguments and sort using JAVASCRIPT .sort();

        return Object.keys(subCategory).sort().reduce(
            (obj, key) => {
                obj[key] = subCategory[key];
                return obj;
            },
            {}
        );
    }

    _handleSortingCategories = () => {
        // Collect all keys of the object processedData in arguments and sort using JAVASCRIPT .sort();

        let {processedData} = this.state;
        let orderedCategories = Object.keys(processedData).sort().reduce(
            (obj, key) => {
                obj[key] = this._handleSortingSubCategories(processedData[key]); // after sorting categories, drill into the subcategory and sort  before updating the category
                return obj;
            },
            {}
        );

        this.setState({processedData: orderedCategories}, this._handleSummation()); //update processedData and start making sales summation

    }

    _handleSummation = () => {
        const {processedData, states} = this.state;
        let totals = {};
        /**
         * The code is a nested loop from the processed data where it has
         * ProcessedData -> Categories -> SubCatetgoris -> States
         *
         * Then create a new object called totals that is updated with
         * ProcessedData -> Categories -> States SUMMATION OF SALES
         *
         */



        for (const [category, subCategoris] of Object.entries(processedData)) {
            for (const [subcategory, states] of Object.entries(subCategoris)) { // notice that subcategory was never used since it the only one that not needed
                for (const [state, sales] of Object.entries(states)) {
                    if (typeof (totals[category]) == "undefined") {
                        totals[category] = {}
                    }
                    if (typeof (totals[category][state]) == "undefined") {
                        totals[category][state] = 0
                    }
                    totals[category][state] += sales;
                }
            }
        }
        this.setState({totals}) // update totals
        console.log(totals)
    }

    render() {
        const {processedData, states} = this.state;


        const renderCategorySubCategories = (currentObject) => {
            const {states, totals} = this.state;
            let results = [];
            for (const [catKey, category] of Object.entries(currentObject)) {
                let rowspan = Object.keys(category).length
                results[results.length] =
                    <tr>
                        <th className="sticky-col  white-bg first-col" rowSpan={rowspan + 1}>
                            {typeof (catKey) === 'string' ? `${catKey}` : null}
                        </th>
                    </tr>
                for (const [key, subcategory] of Object.entries(category)) {

                    results[results.length] = <tr key={key}>
                        <td className="second-col white-bg sticky-col">{key}</td>
                        {states.map(row => {
                            let sales = subcategory[row] ? Math.round(subcategory[row]) : 0;
                            return <td className="number">{sales}</td>
                        })}
                    </tr>
                }
                results[results.length] = <tr className="totals">
                    <th className="first-col sticky-col">{catKey} Total</th>
                    <th className="second-col sticky-col"></th>

                    {states.map(row => {
                        let sales = (typeof (totals[catKey]) != 'undefined' && typeof (totals[catKey][row]) !== 'undefined') ? Math.round(totals[catKey][row]) : 0;
                        return <td className="number">{sales}</td>
                    })}
                </tr>
            }
            return <tbody>
            {results}
            </tbody>
        }

        return (
            <>  {processedData && <React.Fragment>
                <div className="view">
                    <div className="wrapper">
                        <Table>
                            <thead>
                            <tr className="headerBG">
                                <th className="sticky-col headerBG first-col" colSpan={2}>Products</th>
                                <th colSpan={states.length}>States</th>
                            </tr>
                            <tr className="headerBG">
                                <th className="sticky-col headerBG first-col">Categories</th>
                                <th className="sticky-col headerBG second-col">Sub Categories</th>
                                {states.map(row => <th>{row}</th>)}
                            </tr>
                            </thead>
                            {renderCategorySubCategories(processedData)}
                        </Table>
                    </div>
                </div>
            </React.Fragment>}
            </>
        )
    }
}
