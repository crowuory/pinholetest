import React from 'react';

const Styles = {
    row: {
        width: '100%',
        clear: 'both'
    },
    col1: {
        width: '25%',
        float: 'left'
    },
    col2: {
        width: '50%',
        float: 'left'
    },
    col3: {
        width: '75%',
        float: 'left'
    },
    col4: {
        width: '100%',
        float: 'left'
    },
    container : {

        padding: 5,
        boxShadow: "5px 5px 10px rgba(0,0,0,0.1)",
        height: ((window).innerHeight * 0.98),
    }



};
export {Styles}
