
/*
*
*    *******       *****
*    *******      *******
*    **   **      **   **
*    ****         **   **
*    ****         **   **
*    ** **        **   **
*    **   **      **   **
*    **   **   *   *****
*
*
*
*
* Pinhole Interview Assignment
*
* Both the source code and build are in the root folder,
* to preview the application you will need to run the build in a server
* you can use the node to run the build by running the command >_ serve -s build  _<
* or you can past the content of the build folder in a server
*
* To run the source code on development environment, first follow the instructions below
*
* npm install
*
* OR
*
* npm update
*
* THEN
*
* npm start
*
*
*
* Assumptions
*
* - This application is not responsive since
* - It will be best visible on a wide screen
* - the data has been loaded statically within the application from a .json file.
* - data from a REST API will be compatible to the application as long as the structure is the same as the one provided in the json file
*
*
*
*
* 
* Developments on a real project
*
* - include total sales for each sub category
* - include total sales of each state
* - include total sales made
*
* provide a summary of
*  -- GROSS PROFIT
*  -- SHOW TOTAL PROFIT MADE PER (STATE / CATEGORY / SUB CATEGORY)
*  -- Include chart libraries in order to show sales per states in[ pie charts, bar graphs and/or line graphs    ]
*
* */
